def sum (num1, num2):
    return num1 + num2

def sub (num1, num2):
    return num1 - num2

def mul (num1, num2):
    return num1 * num2

def div(num1, num2):
    return num1 / num2

print(div(1,2))